//
//  Quizz.h
//  Memoria-Visualizacion
//
//  Created by Enrique O Hernandez on 4/30/15.
//  Copyright (c) 2015 NLCJohn. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Quizz : SKScene

@end
