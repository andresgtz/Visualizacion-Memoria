//
//  Resultado_Quiz.h
//  Memoria-Visualizacion
//
//  Created by Jesus on 5/1/15.
//  Copyright (c) 2015 NLCJohn. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Resultado_Quiz : SKScene

@end
