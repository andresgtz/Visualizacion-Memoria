
#import <SpriteKit/SpriteKit.h>

@interface SKEmitterNode (SKTExtras)

+ (instancetype)skt_emitterNamed:(NSString *)name;

@end
