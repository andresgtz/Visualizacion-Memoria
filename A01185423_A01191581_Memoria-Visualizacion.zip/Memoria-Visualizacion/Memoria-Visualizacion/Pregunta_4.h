//
//  Pregunta_4.h
//  Memoria-Visualizacion
//
//  Created by Jesus on 5/1/15.
//  Copyright (c) 2015 NLCJohn. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Pregunta_4 : SKScene

@end
